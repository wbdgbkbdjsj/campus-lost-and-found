<template>
  <div class="page-container">
    <PageHeader
      title="消息通知"
      description="页面骨架：TODO 按《页面清单.md》第 2 节 A7 实现"
    />
    <div class="page-card">
      <EmptyState description="页面骨架已就位，业务待实现" />
    </div>
  </div>
</template>

<script setup lang="ts">
import PageHeader from '@/components/PageHeader.vue'
import EmptyState from '@/components/EmptyState.vue'
</script>
